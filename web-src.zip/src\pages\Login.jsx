import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axiosClient from '../api/axiosClient';
import AuthPanel from '../components/AuthPanel';

function defaultRouteForRole(role) {
  return role === 'SALES_REP' ? '/visits' : '/dashboard';
}

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('ADMIN');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await axiosClient.post('/auth/login', { email, password, role });

      if (response.data.role !== role) {
        setError(`This account is registered as ${response.data.role}, not ${role}. Select the correct role and try again.`);
        setLoading(false);
        return;
      }

      localStorage.setItem('token', response.data.token);
      localStorage.setItem('userId', response.data.userId);
      localStorage.setItem('userName', response.data.name);
      localStorage.setItem('userRole', response.data.role);
      navigate(defaultRouteForRole(response.data.role));
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fsa-auth-shell">
      <AuthPanel variant="login" />

      <div className="fsa-auth-form-side">
        <div className="fsa-auth-form-inner">
          <h2 style={{ fontFamily: 'var(--fsa-display)', fontWeight: 600, fontSize: 24, color: 'var(--fsa-paper)', margin: '0 0 6px' }}>
            Welcome back
          </h2>
          <p style={{ fontSize: 14, color: 'var(--fsa-fog)', margin: '0 0 28px' }}>
            Sign in to your workspace.
          </p>

          <form onSubmit={handleSubmit}>
            <label className="fsa-label">Login as</label>
            <div className="fsa-toggle" role="group" aria-label="Select role">
              <button
                type="button"
                className="fsa-toggle-btn"
                aria-pressed={role === 'ADMIN'}
                onClick={() => setRole('ADMIN')}
              >
                Admin
              </button>
              <button
                type="button"
                className="fsa-toggle-btn"
                aria-pressed={role === 'SALES_REP'}
                onClick={() => setRole('SALES_REP')}
              >
                Sales Rep
              </button>
            </div>

            <label className="fsa-label" style={{ marginTop: 18 }}>Email</label>
            <input
              className="fsa-input"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@company.com"
              required
            />

            <label className="fsa-label" style={{ marginTop: 18 }}>Password</label>
            <input
              className="fsa-input"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
            />

            {error && <div className="fsa-banner fsa-banner-error">{error}</div>}

            <button type="submit" className="fsa-btn-primary" disabled={loading} style={{ marginTop: 22 }}>
              {loading ? 'Signing in...' : 'Log in'}
            </button>

            <p style={{ textAlign: 'center', marginTop: 20, fontSize: 13.5, color: 'var(--fsa-fog)' }}>
              New here?{' '}
              <button type="button" className="fsa-link" onClick={() => navigate('/register')}>
                Create an account
              </button>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;