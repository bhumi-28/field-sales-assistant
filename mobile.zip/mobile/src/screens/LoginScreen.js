import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient from '../api/apiClient';
import { COLORS, RADIUS, FONT } from '../theme';

function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('SALES_REP');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      const response = await apiClient.post('/auth/login', { email, password, role });

      if (response.data.role !== role) {
        setError(`This account is registered as ${response.data.role}, not ${role}.`);
        setLoading(false);
        return;
      }

      await AsyncStorage.multiSet([
        ['token', response.data.token],
        ['userId', String(response.data.userId)],
        ['userName', response.data.name],
        ['userRole', response.data.role],
      ]);

      navigation.reset({ index: 0, routes: [{ name: 'Dashboard' }] });
    } catch (err) {
      setError('Invalid email or password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      {/* diagonal accent block behind the header */}
      <View style={styles.diagonalWrap} pointerEvents="none">
        <View style={styles.diagonal} />
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        <View style={styles.header}>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>FS</Text>
          </View>
          <Text style={styles.wordmarkTop}>FIELD SALES</Text>
          <Text style={styles.wordmarkBottom}>ASSISTANT</Text>
          <Text style={styles.tagline}>Sign in to run your day</Text>
        </View>

        <View style={styles.cardWrap}>
          <View style={[styles.shadowBlock, { backgroundColor: COLORS.cyan }]} />
          <View style={styles.card}>
            <View style={styles.roleToggle}>
              <TouchableOpacity
                style={[
                  styles.roleBtn,
                  role === 'ADMIN' && { backgroundColor: COLORS.cyan, borderColor: COLORS.cyan },
                ]}
                onPress={() => setRole('ADMIN')}
              >
                <Text style={[styles.roleBtnText, role === 'ADMIN' && { color: COLORS.onCyan }]}>
                  Admin
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.roleBtn,
                  role === 'SALES_REP' && { backgroundColor: COLORS.orange, borderColor: COLORS.orange },
                ]}
                onPress={() => setRole('SALES_REP')}
              >
                <Text style={[styles.roleBtnText, role === 'SALES_REP' && { color: COLORS.onOrange }]}>
                  Sales Rep
                </Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              placeholder="you@company.com"
              placeholderTextColor="#4A5160"
              autoCapitalize="none"
              keyboardType="email-address"
            />

            <Text style={styles.label}>Password</Text>
            <TextInput
              style={styles.input}
              value={password}
              onChangeText={setPassword}
              placeholder="••••••••"
              placeholderTextColor="#4A5160"
              secureTextEntry
            />

            {error ? (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            ) : null}

            <View style={styles.buttonWrap}>
              <View style={[styles.buttonShadow, { backgroundColor: COLORS.cyan }]} />
              <TouchableOpacity
                style={[styles.button, loading && styles.buttonDisabled]}
                onPress={handleLogin}
                disabled={loading}
                activeOpacity={0.85}
              >
                {loading ? (
                  <ActivityIndicator color={COLORS.onOrange} />
                ) : (
                  <Text style={styles.buttonText}>LOG IN →</Text>
                )}
              </TouchableOpacity>
            </View>

            <TouchableOpacity onPress={() => navigation.navigate('Register')} style={styles.linkWrap}>
              <Text style={styles.link}>New here? Create an account</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  scrollContent: { flexGrow: 1, padding: 24, paddingTop: 64, paddingBottom: 40 },

  diagonalWrap: { ...StyleSheet.absoluteFillObject, overflow: 'hidden' },
  diagonal: {
    position: 'absolute',
    top: -180,
    left: -60,
    width: '160%',
    height: 320,
    backgroundColor: COLORS.orange,
    transform: [{ rotate: '-8deg' }],
  },

  header: { marginBottom: 28 },
  badge: {
    width: 44,
    height: 44,
    backgroundColor: COLORS.ink,
    borderWidth: 3,
    borderColor: COLORS.text,
    borderRadius: RADIUS,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  badgeText: { color: COLORS.cyan, fontSize: 16, fontWeight: '800' },
  wordmarkTop: { color: COLORS.ink, fontSize: 34, ...FONT.display, lineHeight: 36 },
  wordmarkBottom: { color: COLORS.text, fontSize: 34, ...FONT.display, lineHeight: 38 },
  tagline: { color: COLORS.muted, fontSize: 13.5, marginTop: 10, fontWeight: '500' },

  cardWrap: { position: 'relative' },
  shadowBlock: {
    position: 'absolute',
    top: 8,
    left: 8,
    right: -8,
    bottom: -8,
    borderRadius: RADIUS,
  },
  card: {
    backgroundColor: COLORS.surface,
    borderRadius: RADIUS,
    borderWidth: 3,
    borderColor: COLORS.text,
    padding: 22,
  },

  roleToggle: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  roleBtn: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: RADIUS,
    borderWidth: 2,
    borderColor: COLORS.border,
    backgroundColor: COLORS.surface2,
    alignItems: 'center',
  },
  roleBtnText: { color: COLORS.muted, fontSize: 13, ...FONT.label, letterSpacing: 0.4 },

  label: { color: COLORS.muted, fontSize: 11.5, ...FONT.label, marginBottom: 8, marginTop: 4 },
  input: {
    backgroundColor: COLORS.bg,
    borderWidth: 2,
    borderColor: COLORS.border,
    borderRadius: RADIUS,
    paddingHorizontal: 13,
    paddingVertical: 12,
    color: COLORS.text,
    fontSize: 15,
    marginBottom: 14,
  },

  errorBox: {
    backgroundColor: COLORS.red,
    borderWidth: 2,
    borderColor: COLORS.text,
    borderRadius: RADIUS,
    padding: 11,
    marginBottom: 16,
  },
  errorText: { color: '#1A0000', fontSize: 13, fontWeight: '700' },

  buttonWrap: { position: 'relative', marginTop: 6 },
  buttonShadow: {
    position: 'absolute',
    top: 6,
    left: 6,
    right: -6,
    bottom: -6,
    borderRadius: RADIUS,
  },
  button: {
    backgroundColor: COLORS.orange,
    borderRadius: RADIUS,
    borderWidth: 3,
    borderColor: COLORS.ink,
    paddingVertical: 15,
    alignItems: 'center',
  },
  buttonDisabled: { backgroundColor: COLORS.border, borderColor: COLORS.border },
  buttonText: { color: COLORS.onOrange, fontSize: 15, ...FONT.label, letterSpacing: 1 },

  linkWrap: { marginTop: 20, alignItems: 'center' },
  link: { color: COLORS.cyan, fontSize: 13.5, fontWeight: '700' },
});

export default LoginScreen;