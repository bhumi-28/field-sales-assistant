import { useEffect, useState, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import axiosClient from '../api/axiosClient';

const COLORS = {
  bg: '#0b0d12',
  card: '#12141a',
  border: '#2a2d36',
  text: '#e6e8ec',
  muted: '#8b91a1',
  accent: '#4fd8c9',
  danger: '#e05c5c',
  green: '#4fd8c9',
};

export default function CustomersScreen({ navigation }) {
  const [customers, setCustomers] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const fetchCustomers = useCallback(async () => {
    setError('');
    try {
      const res = await axiosClient.get('/customers');
      setCustomers(res.data);
      setFiltered(res.data);
    } catch {
      setError('Failed to load customers');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { fetchCustomers(); }, [fetchCustomers]);

  useEffect(() => {
    const q = search.toLowerCase();
    setFiltered(
      customers.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          (c.city || '').toLowerCase().includes(q) ||
          (c.phone || '').includes(q)
      )
    );
  }, [search, customers]);

  const onRefresh = () => { setRefreshing(true); fetchCustomers(); };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      activeOpacity={0.75}
      onPress={() => navigation.navigate('CustomerDetails', { customer: item })}
    >
      <View style={styles.cardTop}>
        <Text style={styles.name}>{item.name}</Text>
        <View style={[styles.badge, item.status === 'ACTIVE' ? styles.badgeActive : styles.badgeInactive]}>
          <Text style={styles.badgeText}>{item.status}</Text>
        </View>
      </View>
      {!!item.city && <Text style={styles.meta}>📍 {item.city}</Text>}
      {!!item.phone && <Text style={styles.meta}>📞 {item.phone}</Text>}
      {!!item.email && <Text style={styles.meta}>✉️ {item.email}</Text>}
      <Text style={styles.action}>View details →</Text>
    </TouchableOpacity>
  );

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator color={COLORS.accent} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Text style={styles.back}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.title}>My Customers</Text>
        <View style={{ width: 50 }} />
      </View>

      {/* Search */}
      <TextInput
        style={styles.search}
        value={search}
        onChangeText={setSearch}
        placeholder="Search by name, city, phone..."
        placeholderTextColor={COLORS.muted}
      />

      {error ? (
        <Text style={styles.error}>{error}</Text>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.accent} />}
          ListEmptyComponent={
            <Text style={styles.empty}>No customers found</Text>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  center: { flex: 1, backgroundColor: COLORS.bg, alignItems: 'center', justifyContent: 'center' },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
  },
  back: { color: COLORS.accent, fontSize: 14, fontWeight: '600', width: 50 },
  title: { fontSize: 17, fontWeight: '700', color: COLORS.text },

  search: {
    marginHorizontal: 20,
    marginBottom: 16,
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    paddingHorizontal: 14,
    paddingVertical: 11,
    color: COLORS.text,
    fontSize: 14,
  },

  list: { paddingHorizontal: 20, paddingBottom: 30 },

  card: {
    backgroundColor: COLORS.card,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  name: { fontSize: 15, fontWeight: '700', color: COLORS.text, flex: 1, marginRight: 8 },

  badge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  badgeActive: { backgroundColor: '#16302c' },
  badgeInactive: { backgroundColor: '#2a1a1a' },
  badgeText: { fontSize: 11, fontWeight: '600', color: COLORS.accent },

  meta: { fontSize: 13, color: COLORS.muted, marginBottom: 4 },
  action: { fontSize: 12, color: COLORS.accent, marginTop: 8, fontWeight: '600' },

  empty: { color: COLORS.muted, textAlign: 'center', marginTop: 40, fontSize: 14 },
  error: { color: COLORS.danger, textAlign: 'center', marginTop: 30, fontSize: 14 },
});