import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient from '../api/apiClient';
import { COLORS, RADIUS, FONT } from '../theme';

// each metric gets its own signature color for the hard-shadow block
const METRIC_COLORS = [COLORS.orange, COLORS.cyan, COLORS.green, COLORS.yellow];

function DashboardScreen({ navigation }) {
  const [userName, setUserName] = useState('');
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const loadSummary = useCallback(async () => {
    try {
      const res = await apiClient.get('/dashboard/summary');
      setSummary(res.data);
      setError('');
    } catch (err) {
      setError('Could not load dashboard. Pull down to retry.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      AsyncStorage.getItem('userName').then((n) => setUserName(n || ''));
      loadSummary();
    }, [loadSummary])
  );

  const handleRefresh = () => {
    setRefreshing(true);
    loadSummary();
  };

  const handleLogout = async () => {
    await AsyncStorage.clear();
    navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
  };

  const metrics = [
    { label: 'Visits This Month', value: summary?.visitsThisMonth },
    { label: 'Pending Follow-ups', value: summary?.pendingFollowUps },
    { label: 'Total Customers', value: summary?.totalCustomers },
    { label: 'High Opportunities', value: summary?.highOpportunities },
  ];

  const actions = [
    { label: 'Customers', onPress: () => navigation.navigate('CustomerList'), color: COLORS.cyan },
    { label: 'Follow-up Tasks', onPress: () => navigation.navigate('Tasks'), color: COLORS.orange },
    { label: 'AI Assistant', onPress: () => navigation.navigate('AiAssistant'), color: COLORS.green },
  ];

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={COLORS.orange} />
      }
    >
      <View style={styles.header}>
        <View style={styles.headerStripe} />
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.greeting}>Hi{userName ? `, ${userName}` : ''}</Text>
            <Text style={styles.subtitle}>Here's your day at a glance</Text>
          </View>
          <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
            <Text style={styles.logoutText}>LOGOUT</Text>
          </TouchableOpacity>
        </View>
      </View>

      {loading ? (
        <ActivityIndicator color={COLORS.orange} style={{ marginTop: 40 }} />
      ) : (
        <>
          {error ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{error}</Text>
            </View>
          ) : null}

          <View style={styles.metricsGrid}>
            {metrics.map((m, i) => (
              <View key={m.label} style={styles.metricWrap}>
                <View
                  style={[styles.metricShadow, { backgroundColor: METRIC_COLORS[i % METRIC_COLORS.length] }]}
                />
                <View style={styles.metricCard}>
                  <Text style={styles.metricValue}>{m.value ?? '—'}</Text>
                  <Text style={styles.metricLabel}>{m.label}</Text>
                </View>
              </View>
            ))}
          </View>

          {(summary?.competitiveAlerts ?? 0) > 0 && (
            <View style={styles.alertBanner}>
              <Text style={styles.alertText}>
                ⚠ {summary?.competitiveAlerts} COMPETITIVE ALERT
                {summary?.competitiveAlerts !== 1 ? 'S' : ''} NEED ATTENTION
              </Text>
            </View>
          )}

          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionsGrid}>
            {actions.map((a) => (
              <View key={a.label} style={styles.actionWrap}>
                <View style={[styles.actionShadow, { backgroundColor: a.color }]} />
                <TouchableOpacity style={styles.actionCard} onPress={a.onPress} activeOpacity={0.85}>
                  <View style={[styles.actionDot, { backgroundColor: a.color }]} />
                  <Text style={styles.actionText}>{a.label}</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  content: { padding: 20, paddingBottom: 40 },

  header: { marginBottom: 24 },
  headerStripe: {
    position: 'absolute',
    top: -20,
    left: -20,
    right: -20,
    height: 90,
    backgroundColor: COLORS.orange,
    transform: [{ rotate: '-2deg' }],
    zIndex: -1,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingTop: 4,
  },
  greeting: { color: COLORS.text, fontSize: 24, ...FONT.display },
  subtitle: { color: COLORS.muted, fontSize: 13, marginTop: 4, fontWeight: '500' },
  logoutBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: RADIUS,
    borderWidth: 2,
    borderColor: COLORS.text,
    backgroundColor: COLORS.ink,
  },
  logoutText: { color: COLORS.text, fontSize: 11, ...FONT.label },

  errorBox: {
    backgroundColor: COLORS.red,
    borderWidth: 2,
    borderColor: COLORS.text,
    borderRadius: RADIUS,
    padding: 11,
    marginBottom: 16,
  },
  errorText: { color: '#1A0000', fontSize: 13, fontWeight: '700' },

  metricsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 16, marginBottom: 22 },
  metricWrap: { width: '44%', position: 'relative' },
  metricShadow: {
    position: 'absolute',
    top: 6,
    left: 6,
    right: -6,
    bottom: -6,
    borderRadius: RADIUS,
  },
  metricCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 2.5,
    borderColor: COLORS.text,
    borderRadius: RADIUS,
    padding: 16,
  },
  metricValue: { color: COLORS.text, fontSize: 28, ...FONT.display },
  metricLabel: { color: COLORS.muted, fontSize: 11, ...FONT.label, marginTop: 8 },

  alertBanner: {
    backgroundColor: COLORS.yellow,
    borderWidth: 2.5,
    borderColor: COLORS.ink,
    borderRadius: RADIUS,
    padding: 13,
    marginBottom: 22,
  },
  alertText: { color: COLORS.onYellow, fontSize: 12.5, fontWeight: '800', letterSpacing: 0.3 },

  sectionTitle: { color: COLORS.text, fontSize: 15, ...FONT.heading, marginBottom: 14 },
  actionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  actionWrap: { flexGrow: 1, minWidth: '28%', position: 'relative' },
  actionShadow: {
    position: 'absolute',
    top: 6,
    left: 6,
    right: -6,
    bottom: -6,
    borderRadius: RADIUS,
  },
  actionCard: {
    backgroundColor: COLORS.surface,
    borderWidth: 2.5,
    borderColor: COLORS.text,
    borderRadius: RADIUS,
    paddingVertical: 18,
    alignItems: 'center',
  },
  actionDot: { width: 10, height: 10, borderRadius: 2, marginBottom: 8 },
  actionText: { color: COLORS.text, fontSize: 12.5, ...FONT.label, letterSpacing: 0.3, textAlign: 'center' },
});

export default DashboardScreen;