// Shared design tokens — bold "field-ops" look: flat color blocks, thick
// ink borders, hard offset shadows (solid color blocks, no blur/glow).
// Import { COLORS, RADIUS, FONT } anywhere instead of a local COLORS object.

export const COLORS = {
  bg: '#0A0C10',
  surface: '#14181F',
  surface2: '#1C2129',
  ink: '#05060A',
  border: '#262B35',
  text: '#F5F7FA',
  muted: '#7C8496',

  orange: '#FF6B35',
  cyan: '#00D9FF',
  green: '#3DDC84',
  yellow: '#FFC93C',
  red: '#FF4757',

  onOrange: '#180800',
  onCyan: '#001217',
  onGreen: '#00140A',
  onYellow: '#1A1200',
};

export const RADIUS = 6;

export const FONT = {
  display: { fontWeight: '800' as const, letterSpacing: -0.5 },
  heading: { fontWeight: '700' as const, letterSpacing: -0.2 },
  label: { fontWeight: '700' as const, letterSpacing: 0.6, textTransform: 'uppercase' as const },
  body: { fontWeight: '500' as const },
};

// Usage pattern for the signature "hard shadow" (a solid color block offset
// behind a card, instead of a blurred rgba shadow):
//
// <View style={{ position: 'relative' }}>
//   <View style={[styles.shadowBlock, { backgroundColor: COLORS.cyan }]} />
//   <View style={styles.card}>...</View>
// </View>
//
// where shadowBlock is StyleSheet.absoluteFillObject with
// { top: 6, left: 6 } added (see LoginScreen / DashboardScreen for the
// concrete StyleSheet entries).