import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Android emulator -> 10.0.2.2 maps to your machine's localhost.
// iOS simulator -> 'localhost' works directly.
// Physical device -> replace with your machine's LAN IP, e.g. http://192.168.1.5:8081/api
const BASE_URL = 'http://10.0.2.2:8081/api';

const axiosClient = axios.create({ baseURL: BASE_URL });

axiosClient.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

axiosClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await AsyncStorage.multiRemove(['token', 'userName', 'userRole']);
    }
    return Promise.reject(error);
  }
);

export default axiosClient;